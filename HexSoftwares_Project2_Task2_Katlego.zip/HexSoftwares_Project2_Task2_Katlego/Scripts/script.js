// Dynamic Floating Shapes
const floatingShapes = document.querySelector('.floating-shapes');

function createShape() {
    const shape = document.createElement('div');
    const size = Math.random() * 50 + 20;
    shape.style.width = `${size}px`;
    shape.style.height = `${size}px`;
    shape.style.position = 'absolute';
    shape.style.borderRadius = '50%';
    shape.style.background = `rgba(255, 255, 255, 0.3)`;
    shape.style.top = `${Math.random() * 100}%`;
    shape.style.left = `${Math.random() * 100}%`;
    shape.style.animation = `float ${Math.random() * 5 + 5}s infinite alternate ease-in-out`;
    floatingShapes.appendChild(shape);

    setTimeout(() => shape.remove(), 10000); // Remove after animation
}

setInterval(createShape, 1000);
