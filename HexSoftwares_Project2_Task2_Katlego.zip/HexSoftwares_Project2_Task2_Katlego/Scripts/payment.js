function redirectToPayment() {
    const plan = document.getElementById('plan').value;

    // Check if a plan is selected
    if (!plan) {
        alert("Please select a membership plan before proceeding.");
        return;
    }

    // Redirect to a simulated payment portal with selected plan information
    const name = document.querySelector('input[placeholder="Full Name"]').value;
    const email = document.querySelector('input[placeholder="Email Address"]').value;

    if (!name || !email) {
        alert("Please complete all required fields before proceeding.");
        return;
    }

    // Pass plan and user info as query parameters
    const paymentUrl = `payment.html?plan=${plan}&name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}`;
    window.location.href = paymentUrl;
}
